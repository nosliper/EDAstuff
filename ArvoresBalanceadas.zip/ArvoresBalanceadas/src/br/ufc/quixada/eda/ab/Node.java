package br.ufc.quixada.eda.ab;

public class Node<K extends Comparable<K>, V> {
	private K key;
	private V value;
	private int height;
	private Node<K, V> right = null;
	private Node<K, V> left = null;
	public Node() {
		this.value = null;
	}
	public Node(K key) {
		super();
		this.key = key;
	}
	public Node(K key, V value) {
		this.key = key;
		this.value = value;
	}
	public K getKey() {
		return key;
	}
	public void setKey(K key) {
		this.key = key;
	}
	public V getValue() {
		return value;
	}
	public void setValue(V value) {
		this.value = value;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public Node<K, V> getRight() {
		return right;
	}
	public void setRight(Node<K, V> right) {
		this.right = right;
	}
	public Node<K, V> getLeft() {
		return left;
	}
	public void setLeft(Node<K, V> left) {
		this.left = left;
	}
	
}
