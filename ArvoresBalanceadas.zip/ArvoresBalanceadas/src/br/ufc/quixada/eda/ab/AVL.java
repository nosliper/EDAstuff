package br.ufc.quixada.eda.ab;

public class AVL<K extends Comparable<K>, V> {
	private Node<K, V> root;
	public AVL() {
		root = new Node<K, V>();
	}
	public boolean isEmpty() {
		return root == null;
	}
	public void insert(K key, V value) {
		root = insert(key, root, value);
	}
	private Node<K, V> insert(K key, Node<K, V> node, V value) {
		if (node == null) {
			node = new Node<K, V>(key, value);
		}
		else if (key.compareTo(node.getKey()) < 0) {
			node.setLeft(insert(key, node.getLeft(), value));
			if (height(node.getLeft()) - height(node.getRight()) == 2) {
				System.out.println(root == null? "1 if " : "1 nao"); //1. tests if must rotate
				if (key.compareTo(node.getLeft().getKey()) < 0) {    //2. tests direction of rotation
					node = rotateLeft(node);
				}
				else {
					node = doubleRotateLeft(node);
				}
			}
		}
		else if (key.compareTo(node.getKey()) > 0) {
			node.setRight(node.getRight());
			if (height(node.getRight()) - height(node.getLeft()) == 2) { //1. '' ''
				if (key.compareTo(node.getRight().getKey()) > 0) {   //2. '' '' (in order not to bug myself)
					node = rotateRight(node);
				}
				else {
					node = doubleRotateRight(node);
				}
			}
		}
		int lH = height(node.getLeft());
		int rH = height(node.getRight());
		node.setHeight(max(lH, rH) + 1);
		return node;
	}
	private int max(int a, int b) {
		return Math.max(a, b);
	}
	private int height(Node<K, V> node) {
		return node != null? node.getHeight() : -1;
	}
	private Node<K, V> rotateLeft(Node<K, V> nodeA) {
		System.out.println("left coisou"); //TODO:
		Node<K, V> nodeB = nodeA.getRight();
		nodeA.setRight(nodeB.getLeft());
		nodeB.setLeft(nodeA);
		int aL = height(nodeA.getLeft());
		int aR = height(nodeA.getRight());
		nodeA.setHeight(max(aL, aR) + 1);
		int bR = height(nodeB.getRight());
		nodeB.setHeight(max(bR, nodeA.getHeight()) + 1);
		return nodeB;
	}
	private Node<K, V> rotateRight(Node<K, V> nodeA) {
		Node<K, V> nodeB = nodeA.getLeft();
		nodeA.setLeft(nodeB.getRight());
		nodeB.setRight(nodeA);
		int aL = height(nodeA.getLeft());
		int aR = height(nodeA.getRight());
		nodeA.setHeight(max(aL, aR) + 1);
		int bR = height(nodeB.getRight());
		nodeB.setHeight(max(bR, nodeA.getHeight()) + 1);
		return nodeB;
	}
	private Node<K, V> doubleRotateLeft(Node<K, V> nodeA) {
		nodeA.setLeft(rotateRight(nodeA).getLeft());
		return rotateLeft(nodeA);
	}
	private Node<K, V> doubleRotateRight(Node<K, V> nodeA) {
		nodeA.setRight(rotateLeft(nodeA).getRight());
		return rotateRight(nodeA);
	}
}
