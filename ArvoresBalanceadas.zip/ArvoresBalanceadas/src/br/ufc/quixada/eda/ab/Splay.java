package br.ufc.quixada.eda.ab;


/*
 * @author diegoavila
 * */
public class Splay<K extends Comparable<K>, V> {
	private Node<K, V> root = null;
	public Splay() {
		root = null;
	}
	public boolean isEmpty() {
		return root == null;
	}
	private Node<K, V> rotateLeft(Node<K, V> nodeA) {
		Node<K, V> nodeB = nodeA.getRight();
		nodeA.setRight(nodeB.getLeft());
		nodeB.setLeft(nodeA);
		return nodeB;
	}
	private Node<K, V> rotateRight(Node<K, V> nodeA) {
		Node<K, V> nodeB = nodeA.getLeft();
		nodeA.setLeft(nodeB.getRight());
		nodeB.setRight(nodeA);
		return nodeB;
	}
	public boolean insert(K key) {
		if (root == null) {
			root = new Node<K, V>(key);
			return true;
		}
		root = splay(root, key);
		if (key.compareTo(root.getKey()) < 0) {
			Node<K, V> newNode = new Node<K, V>(key);
			newNode.setLeft(root.getLeft());
			newNode.setRight(root);
			root.setLeft(null);
			root = newNode;
			return true;
		}
		else if (key.compareTo(root.getKey()) > 0) {
			Node<K, V> newNode = new Node<K, V>(key);
			newNode.setRight(root.getRight());
			newNode.setLeft(root);
			root.setRight(null);
			root = newNode;
			return true;
		}
		else {
			return false;
		}
	}
	public boolean remove(K key) {
		if (root == null) {
			return false; 
		}
		root = splay(root, key);
		if (key.compareTo(root.getKey()) == 0) {
			if (root.getRight() == null) {
				root = root.getLeft();
			}
			//brings up the closest key to the removed key
			else {
				Node<K, V> aux = root.getLeft();
				root = root.getRight();
				splay(root, key);
				root.setLeft(aux);
			}
			return true;
		}
		return false;
	}
	public Node<K, V> search(K key) {
		root = splay(root, key);
		if (root != null && key.compareTo(root.getKey()) == 0) {
			return root; 
		}
		return null;
	}
	private Node<K, V> splay(Node<K, V> node, K key) { //TODO: reduce this method into small ones
		if (node == null) {
			return null;
		}
		//1. decide for left direction:
		if (key.compareTo(node.getKey()) < 0) {
			if (node.getLeft() == null) {
				return node;
			}
			//2. decides what rotations must be made:
			if (key.compareTo(node.getLeft().getKey()) < 0) {
				Node<K, V> newLeft = splay(node.getLeft().getLeft(), key);
				node.getLeft().setLeft(newLeft); 
				node = rotateRight(node);
			}
			else if (key.compareTo(node.getLeft().getKey()) > 0) {
				Node<K, V> newRight = splay(node.getLeft().getRight(), key);
				node.getLeft().setRight(newRight);
				if (node.getLeft().getRight() != null) {					
					node = rotateLeft(node);
				}
			}
			if (node.getLeft() == null) {
				return node;
			}
			else {
				return rotateRight(node);
			}
		}
		//1. '' '' '':
		else if (key.compareTo(node.getKey()) > 0) {
			if (node.getRight() == null) {
				return node;
			}
			//2. '' '' '':
			if (key.compareTo(node.getRight().getKey()) < 0) {
				Node<K, V> newLeft = splay(node.getRight().getLeft(), key);
				node.getRight().setLeft(newLeft);
				if (node.getRight().getLeft() != null) {
					node = rotateRight(node);
				}
			}
			else if (key.compareTo(node.getRight().getKey()) > 0) {
				Node<K, V> newRight = splay(node.getRight().getRight(), key);
				node.getRight().setRight(newRight);
				node = rotateLeft(node);
			}
			if (node.getRight() == null) {
				return node;
			}
			else {
				return rotateLeft(node);
			}
		}
		else {
			return node;
		}
	}
}
