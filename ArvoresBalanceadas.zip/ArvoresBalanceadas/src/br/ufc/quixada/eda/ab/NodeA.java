package br.ufc.quixada.eda.ab;

public class NodeA {

}
