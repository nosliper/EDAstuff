package br.ufc.quixada.eda.ab;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Reader {
	public static Veiculo fillVeiculo(String fileLine) {
		String[] attr = fileLine.split(", ");
		for (int i = 0; i < attr.length; i++) {
			attr[i] = attr[i].split("=")[1];
		}
		return new Veiculo(attr[0], attr[1], attr[2], attr[3], attr[4], attr[5]);
	}
	public static ArrayList<String> getLines(String filePath) throws IOException {
		ArrayList<String> result = new ArrayList<>();
		try {
			FileReader file = new FileReader(filePath);
			BufferedReader reader = new BufferedReader(file);
			String line = reader.readLine();
			while (line != null) {
				result.add(line);
				line = reader.readLine();
			}
			reader.close();
		}
		catch(IOException e) {
			throw new IOException();
		}
		return result;
	}
}
