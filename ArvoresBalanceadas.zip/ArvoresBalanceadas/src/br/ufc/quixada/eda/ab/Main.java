package br.ufc.quixada.eda.ab;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Main {
	private final static String INSTANCE_PATH = "veiculosC.txt";
	public static void main(String[] args) {
		RubroNegra<String, Veiculo> rn = new RubroNegra<>();
		AVL<String, Veiculo> avl = new AVL<>();
		ArrayList<String> lines = new ArrayList<>();
		try {
			lines = Reader.getLines(INSTANCE_PATH);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		//Rubro Negra benchmark:
		long startTimeInsert = System.currentTimeMillis();
		for (String line : lines) {
			Veiculo veiculo = Reader.fillVeiculo(line);
			rn.inserir(veiculo.getRenavam(), veiculo);
		}
		long insertTime = System.currentTimeMillis() - startTimeInsert;
		System.out.println("Tempo total para inserção: " + insertTime + "ms");
		
		// --- -- -- -- -- -- - -- -
		long startTimeSearch = System.currentTimeMillis();
		int len = lines.size();
		for (int i = 0; i < (int)(len * 0.3); i++) {
			int index = new Random().nextInt(len);
			Veiculo v = Reader.fillVeiculo(lines.get(index));
			rn.busca(v.getRenavam());
		}
		long searchTime = System.currentTimeMillis() - startTimeSearch;
		System.out.println("Tempo total de busca de 30%: " + searchTime + "ms");
		// -- -- -- -- --- - - - - - -
//		long startTimeRemove = System.currentTimeMillis();
//		for (int i = 0; i < (int)(len * 0.3); i++) {
//			int index = new Random().nextInt(len);
//			Veiculo v = Reader.fillVeiculo(lines.get(index));
//			rn.remover(v.getRenavam());
//		}
//		long removeTime = System.currentTimeMillis() - startTimeRemove;
//		System.out.println("Tempo total de remoção de 30%: " + removeTime + "ms");
		
		//AVL
//		long startTAVL = System.currentTimeMillis();
//		for (String line : lines) {
//			Veiculo veiculo = Reader.fillVeiculo(line);
//			avl.insert(veiculo.getRenavam(), veiculo);
//		}
//		long endTAVL = System.currentTimeMillis() - startTAVL;
//		System.out.println("Tempo total AVL, inserção: " + endTAVL + "ms");
		
	}
}
